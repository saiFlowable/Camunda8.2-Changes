package org.camunda.community.examples.dmn.rest;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RestApiClient {
    private final RestTemplate restTemplate;

    public RestApiClient() {
        this.restTemplate = new RestTemplate();
    }


    public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType) {

        return  restTemplate.exchange(url, method, requestEntity, responseType);

    }
}

