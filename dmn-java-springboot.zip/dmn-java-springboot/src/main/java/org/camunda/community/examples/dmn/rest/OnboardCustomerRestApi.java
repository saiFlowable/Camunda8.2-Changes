package org.camunda.community.examples.dmn.rest;

import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.response.ProcessInstanceEvent;
import org.camunda.community.examples.dmn.process.OnboardingProcessVariables;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ServerWebExchange;

@RestController
public class OnboardCustomerRestApi {



    @Autowired
    private ZeebeClient zeebeClient;

    private RestTemplate resTempalate = new RestTemplate();

    @Autowired
    private RestApiClient restApiClient;

    public OnboardCustomerRestApi() {
        this.resTempalate = new RestTemplate();
        this.restApiClient = new RestApiClient();
    }
    @PutMapping("/customer")
    public ResponseEntity<String> startOnboarding(ServerWebExchange exchange) {
        // TODO: add data to the process instance from REST request
        String reference = startOnboarding("prepaid", 75, 10);

        // And just return something for the sake of the example
        return ResponseEntity
                .status(HttpStatus.OK)
                .body("Started process instance " + reference);
    }

    public String startOnboarding(String paymentType, long customerRegionScore, long monthlyPayment) {
        OnboardingProcessVariables processVariables = new OnboardingProcessVariables().setPaymentType(paymentType).setCustomerRegionScore(customerRegionScore).setMonthlyPayment(monthlyPayment);

        ProcessInstanceEvent processInstance = zeebeClient.newCreateInstanceCommand()
                .bpmnProcessId("CustomerOnboarding")
                .latestVersion()
                .variables(processVariables)
                .send().join(); // blocking call!

        return String.valueOf( processInstance.getProcessInstanceKey() );
    }

    @GetMapping("/customerPost")
    public String startOn() {
        WebClient client = WebClient.create("https://jsonplaceholder.typicode.com");

        String responseBody = client.get()
                .uri("/posts/1")
                .retrieve()
                .bodyToMono(String.class)
                .block();

        System.out.println(responseBody);
        return String.valueOf(responseBody);
    }

    @PostMapping("/customerNewTest")
    public ResponseEntity<String> startOnboardingNewTest() {
        // TODO: add data to the process instance from REST request
        String url ="http://localhost:8081/v1/tasks/search";
        HttpHeaders headers =new HttpHeaders();
        headers.add("Content-Type","application/json");
        HttpEntity<String> requestEntity=new HttpEntity<>(null,headers);

        ResponseEntity<String> response=restApiClient.exchange(url, HttpMethod.GET,requestEntity,String.class);

        System.out.println("response ======="+response);

        String restApi="http://localhost:8081/v1/tasks/2251799813685258";
        ResponseEntity<String> responseA=restApiClient.exchange(url, HttpMethod.GET,requestEntity,String.class);


        System.out.println("response ======="+responseA);

        String body=responseA.getBody();
        JSONObject json=new JSONObject();
        String data= (String) json.get("processInstanceKey");
        
        String urlTaskApi="http://localhost:8081/v1/tasks/search";
        String jsonBody="{\"processInstanceKey\":\""+data+"\"}";
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> requestEntityTasks=new HttpEntity<>(body,headers);

        ResponseEntity<String> responseB=restApiClient.exchange(urlTaskApi, HttpMethod.POST,requestEntity,String.class);

System.out.println("response ======="+responseB);


        return response;
    }
}
